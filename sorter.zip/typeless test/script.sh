gcc -g testsorter.c
cat testdata.csv | ./a.out